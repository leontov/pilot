#include "kolibri_globals.h"

// Определение глобальных переменных
int server_sock = -1;
rules_t rules;
decimal_cell_t cell;
